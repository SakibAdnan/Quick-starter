<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">	
        <!-- Place favicon.ico in the root directory -->
	   <?php wp_footer(); ?>
    </head>
<body>

<header>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="header-logo">
                   <?php 
                        if (has_custom_logo( )) {
                            the_custom_logo( );
                        }else{
                            echo "<h1><a href='".esc_url( home_url( "/" ) )."'>".get_bloginfo( "name" )."</a></h1>";
                        }
                    ?>
                </div> <!-- end header__logo -->
            </div>
            <div class="col-lg-9">
                <nav class="header-nav">
                    <?php 
                        wp_nav_menu(array(
                            "theme_location" => "primary",
                            "menu_id" => "topmenu",
                            "menu_class" => "header__nav"
                        ));
                     ?>
                </nav>
            </div>
        </div>
    </div>
</header>