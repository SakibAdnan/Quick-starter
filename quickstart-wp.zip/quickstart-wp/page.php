<?php
get_header();
?>

	<div id="page-wraper" >
			<?php

		/* Start the Loop */
		while ( have_posts() ) :
			the_post();?>


			<section class="section-name">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<h1><?php the_title(); ?></h1>
							<?php the_content( ); ?>
						</div>
					</div>
				</div>
			</section>


		<?php 
		endwhile; // End of the loop.
		?>

	</div><!-- #wraper -->

<?php
get_footer();
