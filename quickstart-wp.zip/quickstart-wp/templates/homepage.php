<?php 
//Template Name: Home Page
get_header();
the_post();
?>

<section class="section-name">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h1><?php the_title(); ?></h1>
			</div>
		</div>
	</div>
</section>

<?php get_footer(); ?>