<?php 
require_once get_theme_file_path( "/lib/csf/codestar-framework.php" );
require_once get_theme_file_path( "/inc/custom-post.php" );
require_once get_theme_file_path( "/inc/metaboxes.php" );
require_once get_theme_file_path( "/inc/theme-option.php" );

//Theme setup
function themename_after_setup_theme(){
	load_theme_textdomain( 'themename', '/languages');
	add_theme_support( 'title-tag' );
	add_theme_support( "custom-logo" );
	add_theme_support( "post-thumbnails" );
	add_theme_support( "html5", array('search-form', 'comment-form', 'comment-list') );
	add_image_size( "themename-squier", 400, 400, true );
	add_editor_style( '/assets/css/editor-style.css' );


	register_nav_menu( "primary",__("Top Menu", "themename"));
}
add_action('after_setup_theme', 'themename_after_setup_theme');

// Theme file bootstraping 
function themename_theme_filse(){
	// call Theme css
	wp_enqueue_style('bootstarp-css', get_theme_file_uri( '/assets/css/bootstrap.min.css' ), null, null);
	wp_enqueue_style('bootstarp-css', get_theme_file_uri( '/assets/css/fontawesome.min.css' ), null, null);
	wp_enqueue_style( "dashicons" );
	wp_enqueue_style('themename-theme-css',get_stylesheet_uri());
	wp_enqueue_style('responsive-css', get_theme_file_uri( '/assets/css/responsive.css' ), null, null);


	// call theme js file 
	wp_enqueue_script('popper-js', get_theme_file_uri('/assets/js/popper.min.js'), array('jquery',), null, true);
	wp_enqueue_script('bootstarp-js', get_theme_file_uri('/assets/js/bootstrap.min.js'), array('jquery',), null, true);
	wp_enqueue_script('thmename-main-js', get_theme_file_uri('/assets/js/main.js'), array('jquery',), null, true);
}
add_action('wp_enqueue_scripts', 'themename_theme_filse');

// themename theme sidebar regester
function themename_sidebars(){
	register_sidebar( array(
			"name" => __("Single Post Sidebr", "alpha"),
			"description" => __("Post right sidebar", "alpha"),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			"after_widget" => "</section>",
			"id" => "alpha_sidebar_1",
			"before_title" => "<h3>",
			"after_title" => "</h3>"
		)
	);

}
add_action( 'widgets_init', 'themename_sidebars' );