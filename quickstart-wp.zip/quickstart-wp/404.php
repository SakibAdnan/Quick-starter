<?php 
get_header();
 ?>
	<div class="page-wrapper">
		 <div class="error-page-content">
		 	<div class="container">
		 		<div class="row">
		 			<div class="col-lg-12 text-center">
			 			<div class="error-info">
			 				 <h1><?php 	echo _e( "404 ", "lazycat"); ?></h1>
			 				 <h3><?php 	echo _e( "Is Not Found!", "lazycat"); ?></h3>
			 				 <a href="<?php echo esc_url( home_url( ) ); ?>" class="border-btn hero-slide-btn"><?php _e( "< Back to Home", "lazycat"); ?></a>
			 			</div>
		 			</div>
		 		</div>
		 	</div>
		 </div>
	</div>
 <?php 
 get_footer(); 
 ?>