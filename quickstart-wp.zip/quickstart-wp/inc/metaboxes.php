<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  // Create a metabox
  CSF::createMetabox( $prefix, array(
    'title'     => __('Post Meta box', 'themename'),
    'post_type' => 'post',
  ) );


  // Create a section
CSF::createSection( $prefix, array(
	'title'  => __('Section Type', 'themename'),
	'fields' => array(

		array(
			'id'        => 'demu-text',
			'type'      => 'text',
			'title'     => __('demo text', 'themename'),
			)
		array(
			'id'        => 'demo-textarea',
			'type'      => 'textarea',
			'title'     => __('demu textarea', 'themename'),
			)

	    ),
	) 
);

}
