<?php 

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'theme_option';

  //
  // Create options
  CSF::createOptions( $prefix, array(
    'menu_title' => __('thmeename Theme Option','thmeename'),
    'menu_slug'  => 'theme-option',
  ) );

 
  CSF::createSection( $prefix, array(
    'title'  => __( 'Footer Option','thmeename'),
    'fields' => array(

      array(
        'id'    => 'title',
        'type'  => 'text',
        'title' => __('Footer about title','thmeename'),
        'default' => __('About Meal', 'thmeename')
      ),

      array(
        'id'    => 'desc',
        'type'  => 'textarea',
        'title' => __('Footer About Description ', 'thmeename'),
      ),

      array(
        'id'    => 'newsletter',
        'type'  => 'text',
        'title' => __('Newsletter Heading','thmeename'),
        'default' => __('Newsletter', 'thmeename')
      ),

      array(
        'id'    => 'footer_bottom',
        'type'  => 'text',
        'title' => __('Footer Bottom Text','thmeename'),
      ),
    )
  )

);


}










