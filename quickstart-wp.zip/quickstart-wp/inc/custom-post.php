<?php 


/**
 * Registers a new post type
 * @uses $wp_post_types Inserts new post type object into the list
 *
 * @param string  Post type key, must not exceed 20 characters
 * @param array|string  See optional args description above.
 * @return object|WP_Error the registered post type object, or an error object
 */
function thmename_reggister_post_types() {

	register_post_type( 'postname', 
		array(
			'labels' => array(
				'name'               => __( 'Recipes', 'themename' ),
				'singular_name'      => __( 'Recipe', 'themename' ),
				'add_new'            => __( 'Add New Recipe', 'themename' ),
				'add_new_item'       => __( 'Add New Recipe', 'themename' ),
			),
			'taxonomies'          => array('category'),
			'public'              => true,
			'show_ui'             => true,
			'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt'),
		)
	);


}

add_action( 'init', 'thmename_reggister_post_types' );