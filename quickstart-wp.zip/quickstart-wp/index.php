
<?php
get_header();
?>

    <div id="page-wraper" >
        <section class="section-name">
            <div class="container">
                <div class="row">
                <?php
                /* Start the Loop */
                while ( have_posts() ) :
                    the_post();?>

                    <div class="col-lg-12">
                        <h1><?php the_title(); ?></h1>
                        <?php the_content( ); ?>
                    </div>

                <?php 
                endwhile; // End of the loop.
                ?>
               </div>
            </div>
        </section>
    </div><!-- #wraper -->

<?php
get_footer();
